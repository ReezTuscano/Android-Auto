Lucky Boot Animator (beta 1)

This is an automated program that will conver ANY VIDEO of ANY FORMAT into a bootanimation.zip file.

Features:

Can convert virtually any video format.
Able to trim videos.
Creates a preview video which you can upload to youtube or share with others.
Creates a preview GIF file that you can upload to forums to share with others.
Project folder


Notes:

Phone must be rooted.
Your KERNEL MUST ALLOW custom boot animation.
Videos will be SCALED to the width/height you set.
GIF files has a limitation when it comes to color palettes so the GIF file produced may have lower quality than the videos. This is normal. The low quality is ONLY in the GIF file and has NOTHING to do with the boot animation files.
Boot animation will play when your phone is booting up. The boot animation WILL NOT CARE about the length of your video. As soon as it is done booting, the boot animation will stop. IT WILL NOT WAIT TO PLAY THE WHOLE VIDEO.


Basic Steps:
File->Open Video File (You can also drag/drop the file here)
Click on Create Boot Animation!
Move bootanimation.zip to /system/media
Reboot and enjoy your new boot animation!


TO DO:
Multiple parts (part0 part1 part2 etc)
Sound
Port to an android app.
Help file




Change Log:
beta1 (7-19-12) - beta release
beta1.1 (7-20-12) - fixed no file found issue
