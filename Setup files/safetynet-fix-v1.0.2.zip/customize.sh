#!/sbin/sh

# Set executable permissions
set_perm_recursive $MODPATH/system/bin 0 0 0755 0755
